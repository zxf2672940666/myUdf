package com.mfw.myudf;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;
import org.json.JSONObject;

import java.util.*;

/**
 * @program: myUdf
 * @description: json解析,触发点
 * @author: Liusengen
 * @create: 2019-01-09 15:24
 **/
public class JsonTrigger extends UDF {
    private List<String> list = new ArrayList<String>();

    //json解析
    private void jsonclear(String jsonstr) {
        if (jsonstr == null || jsonstr.length() == 0) {
            return;
        }
        try {
            JSONObject jObj = new JSONObject(jsonstr);
            JSONObject tpreObj = jObj.getJSONObject("_tpre");
            if (tpreObj == null) {
                return;
            }
            try {
                String tp = tpreObj.getString("_tp");
                String tpt = tpreObj.getString("_tpt");
                if (tp.equals(tpt)) {
                    list.add(tp);
                } else {
                    list.add(tp + tpt);
                }
            } catch (Exception e) {
                //
            } finally {
                String s = tpreObj.toString();
                jsonclear(s);
            }
        } catch (Exception e) {
            return;
        }
    }

    //list去重
    private static void removeDuplicate(List list) {
        Set set = new HashSet();
        List newList = new ArrayList();
        for (Iterator it = list.iterator(); it.hasNext(); ) {
            Object element = it.next();
            if (set.add(element)) {
                newList.add(element);
            }
        }
        list.clear();
        list.addAll(newList);
    }

    public Text evaluate(Text a) {
        Integer b = 0;
        return evaluate(a, b);
    }

    public Text evaluate(Text a, Integer b) {
        if (a == null) {
            return null;
        }
        list.clear();
        String c = "_tp";
        String d = "";
        String f = "_tpt";
        String cf = c + f;
        String result = "";
        String jsonstr = a.toString();
        jsonclear(jsonstr);
        removeDuplicate(list);
        for (int i = list.size() - 1; i >= 0; i--) {
            result += list.get(i) + "->";
        }
        try {
            JSONObject jsonObject = new JSONObject(jsonstr);
            c = jsonObject.getString("_tp");
            f = jsonObject.getString("_tpt");
            if (c.equals(f)) {
                cf = c;
            } else {
                cf = c + f;
            }
            d = jsonObject.getString("name");
        } catch (Exception e) {

        } finally {
            if (d.length() == 0) {
                d = c;
            }
            if (!list.contains(cf)) {
                result += cf + "->";
            }
            Boolean flag = !list.contains(d) && !d.equals(cf);
            if (flag) {
                result += d + "->";
            }
            result = result.substring(0, result.length() - 2);
            if (b != 0) {
                String strs[] = result.split("->");
                if (strs[strs.length - 1].equals(c)) {
                    result = result.replace(c, "");
                    if (result.equals("")) {
                        return null;
                    } else {
                        result = result.substring(0, result.length() - 2);
                    }
                }
            }

            Text text = new Text();
            text.set(result);
            return text;
        }
    }
}



