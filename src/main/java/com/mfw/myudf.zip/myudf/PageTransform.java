package com.mfw.myudf;

import com.mfw.utils.FileHandle;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @program: myUdf
 * @description: 将pagename映射到其他字段
 * @author: Mr.Wang
 * @create: 2019-01-20 09:12
 **/
public class PageTransform extends UDF {

    public Text evaluate(Text a) {
        Text text = new Text("std");
        return evaluate(a, text);
    }

    public Text evaluate(Text a, Text b) {
        if (null == a || a.getLength() <= 0) {
            return null;
        }
        Map<String,ArrayList> map=new HashMap();

        String aa=a.toString();
        String bb=b.toString();
        String c=null;
        map = FileHandle.readFileByMap("src/main/java/com/mfw/myudf/std");
        if (bb.equals("std")) {
           c=getField(map,aa,0);
        }else if(bb.equals("channel")){
            c=getField(map,aa,1);
        }else if(bb.equals("level1")){
            c=getField(map,aa,2);
        }else if(bb.equals("level2")){
            c=getField(map,aa,3);
        }else if(bb.equals("level3")){
            c=getField(map,aa,4);
        }else if(bb.equals("types")){
            c=getField(map,aa,5);
            System.out.println(c+"==");
        }else{
            c=null;
        }
        if(null==c){
            return null;
        }
        return new Text(c);

    }

    public  String getField(Map<String,ArrayList> map,String a,int i){

        for (Map.Entry<String, ArrayList> entry : map.entrySet()) {
            if(entry.getValue().size()<i+1){
                return null;
            }
  //          System.out.println(entry.getValue().get(i));
            if(entry.getKey().equals(a)){
                ArrayList<String> list=entry.getValue();
                System.out.println("===");
                return  list.get(i);
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String s="意见反馈";
        Text text=new Text();
        text.set(s);
        PageTransform pageTransform=new PageTransform();
        System.out.println(pageTransform.evaluate(text,new Text("std")));
    }


}



