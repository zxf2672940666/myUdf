package com.mfw.myudf;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;

/**
 * @program: myUdf
 * @description: page的etl udf
 * @author: Mr.Wang
 * @create: 2019-01-19 16:20
 **/
public class PageEtl extends UDF {
    private List<String> list = new ArrayList<String>();
    private String attr_name= null;
    private String attr_tpt=null;
    private String attr_tp=null;
    private String tpre=null;
    private List<String> std_list =new ArrayList<String>();

    public Text evaluate(Text uri,Text puri,Text attr) {
        Integer b = 0;
        return evaluate(uri,puri,attr, b);
    }
    public Text evaluate(Text uri, Text puri,Text attr ,Integer b){
       if(null==uri||null==attr||attr.getLength()==0){
           return null;
       }
       if(uri.toString().length()<=0){
           return null;
       }
        String uri1=uri.toString();
       PageName pageName=new PageName();
       PageTransform pageTransform=new PageTransform();
        String page_u;
        String page_p;
        jsonGetAttr(attr.toString());
       if(null==attr_name||attr_name.length()<=0){
           page_u=null;
       }else{
           Text text=pageName.evaluate(uri,new Text(attr_name));
           Text text1=pageTransform.evaluate(text);
           if(null==text1){
               page_u=null;
           }else{
               page_u=text1.toString();
           }
       }
        if(null==attr_tp||attr_tp.length()<=0||null==puri){
            page_p=null;
        }else{

            Text text=pageName.evaluate(puri,new Text(attr_tp));
            Text text1=pageTransform.evaluate(text);
            if(null==text1){
                page_p=null;
            }else{
                page_p=text1.toString();
            }
        }
        if(page_p!=null&&!page_p.equals(attr_tpt)&&attr_tpt!=null&&!"".equals(attr_tpt)){
            page_p=page_p+"+"+attr_tpt;
        }
        list.clear();
        jsonclear(tpre);
        reverseList1(list);
        if(b==0){
            if(!"".equals(page_p)) {
                list.add(page_p);
            }
        }else{
            if(!"".equals(page_p)) {
                list.add(page_p);
            }
            assert page_u != null;
            if(!"".equals(page_u)) {
                list.add(page_u);
            }
        }
        reverseList1(list);
        StringBuilder re= new StringBuilder();
        for(String s:list){
            re.append(s).append("-->");
        }
        if(re.length()==0){
            return null;
        }else{
            re = new StringBuilder(re.substring(0, re.length() - 3));
            if(re.length()==0){
                return null;
            }else{
                return new Text(re.toString());
            }
        }
    }

    private void jsonGetAttr(String jsonstr) {
        if (jsonstr == null || jsonstr.length() == 0) {
            return;
        }
        try {
            JSONObject jObj = new JSONObject(jsonstr);
            attr_name = jObj.getString("name");
            attr_tpt = jObj.getString("_tpt");
            attr_tp = jObj.getString("_tp");
            tpre=jObj.getString("_tpre");
        } catch (Exception e) {
            return;
        }
    }

    private void jsonclear(String tpre){
        if(tpre==null){
            return;
        }
        PageName pageName=new PageName();
        PageTransform pageTransform=new PageTransform();
        JSONObject jsonObject=null;
        String tp="";
        String tpt="";
        String turi=null;
        try {
            jsonObject=new JSONObject(tpre);
            tp = jsonObject.getString("_tp");
            turi = jsonObject.getString("_turi");
            tpt =jsonObject.getString("_tpt");
        }catch (Exception ignored){

        }finally {

            try {
                tpre = jsonObject.getString("_tpre");
            } catch (Exception ignored) {

            }finally {
                String std = null;
                if (!(null == tp || tp.length() == 0)) {
                    if (turi == null) {
                        std = "非马蜂窝页面";
                    } else {
                        Text text = pageName.evaluate(new Text(turi), new Text(tp));
                        if (null == text) {
                            std = null;
                        } else {
                            Text text1 = pageTransform.evaluate(text);
                            if(text1==null){
                                std=null;
                            }else {
                                std = text1.toString();
                            }
                        }
                    }
                }
                if (null != std) {
                    if ("通用浏览器".equals(tpt) || "酒店下单通用浏览器".equals(tpt) || "".equals(tpt)) {
                        tpt = null;
                    }
                    if (std.equals(tpt)) {
                        list.add(std);
                    } else {
                        if (tpt == null) {
                            list.add(std);
                        } else {
                            list.add(std + "+" + tpt);
                        }
                    }
                }
            }
        }
        jsonclear(tpre);
            }


    private void reverseList1(List<String> list) {
        Collections.reverse(list);
    }

    private  void removeDuplicate(List list) {
        Set set = new HashSet();
        List newList = new ArrayList();
        for (Object element : list) {
            if (set.add(element)) {
                newList.add(element);
            }
        }
        list.clear();
        list.addAll(newList);
    }

    public static void main(String[] args) throws JSONException {
        Text text=new Text();
        Text text1=new Text();
        String url="https://m.mafengwo.cn/poi/poi/detail?poiid=2799";
        String puri="http://app.mafengwo.cn/search/main?keyword=%E9%93%B6%E5%BA%A7";
        String attr="{\"father_umddid\":10183,\"_tp\":\"大搜索\",\"io\":\"o\",\"leaf1\":\"detail\",\"rhost\":\"app\",\"mddid\":\"10222\",\"busclass\":\"poi\",\"identifier\":\"FDD3A2F3B662495AAB7760373161F5E8\",\"_tpt\":\"搜索结果点击\",\"otype\":\"dir\",\"leaf2\":\"\",\"child_channel\":0,\"root\":\"poi\",\"travel_status\":\"{\\\"status\\\":1,\\\"mddid\\\":10222,\\\"strategy\\\":\\\"T6\\\"}\",\"bustype\":3,\"portrait\":\"1\",\"start\":\"1547547797.755949\",\"name\":\"POI详情H5页\",\"url\":\"https://m.mafengwo.cn/poi/poi/detail?poiid=2799\",\"channel_type\":\"other\",\"merge_channel\":2581,\"out\":\"child\",\"travel_status.strategy\":\"T6\",\"_tl\":\"2\",\"rleaf1\":\"main\",\"ref_name\":\"大搜索\",\"_tpre\":\"{\\\"_tpre\\\":{\\\"_turi\\\":\\\"http:\\\\/\\\\/app.mafengwo.cn\\\\/launch\\\",\\\"_tl\\\":\\\"0\\\",\\\"_tp\\\":\\\"启动\\\",\\\"_tid\\\":\\\"8533F6ABB20441C88A3D57857C7C7D48\\\",\\\"_tpi\\\":\\\"启动\\\",\\\"_tpt\\\":\\\"正常\\\"},\\\"_tp\\\":\\\"首页\\\",\\\"_tid\\\":\\\"FAB83FCB1DD7433E9E72CA63AA832E4B\\\",\\\"_tl\\\":\\\"1\\\",\\\"_tpi\\\":\\\"A6E1813F14E8493BB390DA3C4C8DECFC\\\",\\\"_turi\\\":\\\"http:\\\\/\\\\/app.mafengwo.cn\\\\/index\\\",\\\"_tpt\\\":\\\"首页大搜索\\\"}\",\"shumeng_did\":\"D2y/2fKmuuHesLDGtdPSQ1Sj788pkuXldIgSUHD8/oHmkXc9\",\"busid\":\"2799\",\"travel_status.status\":1,\"umddid_state\":10183,\"_m_open_udid_fix\":\"AAC3A901-D20A-4F06-B2A9-FBC0779207A8\",\"type\":\"web\",\"refer\":\"http://app.mafengwo.cn/search/main?keyword=%E9%93%B6%E5%BA%A7\",\"channel\":2581,\"_tpa\":\"启动_首页_大搜索\",\"travel_status.mddid\":10222,\"host\":\"app\",\"in\":\"parent\",\"index_in_launch\":\"2\",\"min\":\"18:24\",\"duration\":\"56.247836\",\"travelling\":1,\"_tid\":\"362140B1C5014A3A91A74D3C125515F6\",\"_tpi\":\"770C66B5DF0D493AB16703EEFB3D2CE4\",\"rroot\":\"search\",\"_turi\":\"http://app.mafengwo.cn/search/main?keyword=%E9%93%B6%E5%BA%A7\"}";
        text.set(url);
        text1.set(puri);
        PageEtl pageEtl=new PageEtl();
        System.out.println(pageEtl.evaluate(text,text1,new Text(attr)));



        /*String tee="{\"father_umddid\":10183,\"_tp\":\"大搜索\",\"io\":\"o\",\"leaf1\":\"detail\",\"rhost\":\"app\",\"mddid\":\"10222\",\"busclass\":\"poi\",\"identifier\":\"FDD3A2F3B662495AAB7760373161F5E8\",\"_tpt\":\"搜索结果点击\",\"otype\":\"dir\",\"leaf2\":\"\",\"child_channel\":0,\"root\":\"poi\",\"travel_status\":\"{\\\"status\\\":1,\\\"mddid\\\":10222,\\\"strategy\\\":\\\"T6\\\"}\",\"bustype\":3,\"portrait\":\"1\",\"start\":\"1547547797.755949\",\"name\":\"POI详情H5页\",\"url\":\"https://m.mafengwo.cn/poi/poi/detail?poiid=2799\",\"channel_type\":\"other\",\"merge_channel\":2581,\"out\":\"child\",\"travel_status.strategy\":\"T6\",\"_tl\":\"2\",\"rleaf1\":\"main\",\"ref_name\":\"大搜索\",\"_tpre\":\"{\\\"_tpre\\\":{\\\"_turi\\\":\\\"http:\\\\/\\\\/app.mafengwo.cn\\\\/launch\\\",\\\"_tl\\\":\\\"0\\\",\\\"_tp\\\":\\\"启动\\\",\\\"_tid\\\":\\\"8533F6ABB20441C88A3D57857C7C7D48\\\",\\\"_tpi\\\":\\\"启动\\\",\\\"_tpt\\\":\\\"正常\\\"},\\\"_tp\\\":\\\"首页\\\",\\\"_tid\\\":\\\"FAB83FCB1DD7433E9E72CA63AA832E4B\\\",\\\"_tl\\\":\\\"1\\\",\\\"_tpi\\\":\\\"A6E1813F14E8493BB390DA3C4C8DECFC\\\",\\\"_turi\\\":\\\"http:\\\\/\\\\/app.mafengwo.cn\\\\/index\\\",\\\"_tpt\\\":\\\"首页大搜索\\\"}\",\"shumeng_did\":\"D2y/2fKmuuHesLDGtdPSQ1Sj788pkuXldIgSUHD8/oHmkXc9\",\"busid\":\"2799\",\"travel_status.status\":1,\"umddid_state\":10183,\"_m_open_udid_fix\":\"AAC3A901-D20A-4F06-B2A9-FBC0779207A8\",\"type\":\"web\",\"refer\":\"http://app.mafengwo.cn/search/main?keyword=%E9%93%B6%E5%BA%A7\",\"channel\":2581,\"_tpa\":\"启动_首页_大搜索\",\"travel_status.mddid\":10222,\"host\":\"app\",\"in\":\"parent\",\"index_in_launch\":\"2\",\"min\":\"18:24\",\"duration\":\"56.247836\",\"travelling\":1,\"_tid\":\"362140B1C5014A3A91A74D3C125515F6\",\"_tpi\":\"770C66B5DF0D493AB16703EEFB3D2CE4\",\"rroot\":\"search\",\"_turi\":\"http://app.mafengwo.cn/search/main?keyword=%E9%93%B6%E5%BA%A7\"}";
        JSONObject jObj = new JSONObject(tee);
        String s=jObj.getString("_tpre");
        System.out.println(jObj.getString("_tpt"));
        System.out.println(jObj.getString("_tpre"));
        JSONObject jsonObject=new JSONObject(s);
        System.out.println(jsonObject.getString("_tpt")+"========");*/


    }
    }







